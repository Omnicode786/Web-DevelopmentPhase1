#include <cs50.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

int letters(string str);
int words(string str);
int sentence(string str);

int main(void)
{
    string text = get_string("Text: ");
    int alphabets = letters(text);
    int word = words(text);
    int sentences = sentence(text);

    float L = alphabets * 100.0 / word;
    float S = sentences * 100.0 / word;
    int index = (int) round((0.0588 * L) - (0.296 * S) - 15.8);

    if (index < 1)
    {
        printf("Before Grade 1\n");
    }
    else if (index >= 1 && index <= 16)
    {
        printf("Grade %d\n", index);
    }
    else
    {
        printf("Grade 16+\n");
    }
}

int letters(string str)
{
    int count = 0;
    for (int i = 0, len = strlen(str); i < len; i++)
    {
        if ((str[i] > 64 && str[i] < 91) || (str[i] > 96 && str[i] < 123))
        {
            count++;
        }
        else
        {
            continue;
        }
    }
    return count;
}

int words(string str)
{
    int count = 0;
    for (int i = 0, len = strlen(str); i < len; i++)
    {
        if (str[i] == ' ')
        {
            count++;
        }
        else
        {
            continue;
        }
    }
    return count + 1;
}

int sentence(string str)
{
    int count = 0;
    for (int i = 0, len = strlen(str); i < len; i++)
    {
        if (str[i] == '.' || str[i] == '!' || str[i] == '?')
        {
            count++;
        }
        else
        {
            continue;
        }
    }
    return count;
}
