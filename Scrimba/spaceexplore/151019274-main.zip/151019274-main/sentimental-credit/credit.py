acc_info = input("Number: ")

sum1 = 0
sum2 = 0

for i in range(len(acc_info)-2, -1, -2):
    if (int(acc_info[i]) * 2) >= 10:
        sum1 += ((int(acc_info[i]) * 2) % 10) + 1
    else:
        sum1 += int(acc_info[i]) * 2

for i in range(len(acc_info)-1, -1, -2):
    sum2 += int(acc_info[i])

sum = sum1 + sum2

if ((str(sum))[-1] == "0") and (acc_info[0] == "3" and acc_info[1] == "7") and (len(acc_info) == 15):
    print("AMEX")
elif ((str(sum))[-1] == "0") and (acc_info[0] == "5" and (acc_info[1] == "1" or acc_info[1] == "2" or acc_info[1] == "3" or acc_info[1] == "4" or acc_info[1] == "5")) and (len(acc_info) == 16):
    print("MASTERCARD")
elif ((str(sum))[-1] == "0") and (acc_info[0] == "4") and (13 <= len(acc_info) <= 16):
    print("VISA")
else:
    print("INVALID")
