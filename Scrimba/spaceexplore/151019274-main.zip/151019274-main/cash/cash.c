#include <cs50.h>
#include <stdio.h>

int change;
int main(void)
{
    int coins = 0;

    do
    {
        change = get_int("Change owed: ");
    }
    while (change < 0);

    coins += change / 25;
    change %= 25;

    coins += change / 10;
    change %= 10;

    coins += change / 5;
    change %= 5;

    coins += change / 1;

    printf("%i\n", coins);
}
