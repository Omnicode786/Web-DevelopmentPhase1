text = input("Text: ")
letters = 0
words = 1
sentence = 0

for i in text:
    if i == " ":
        words += 1
    elif i.isalpha():
        letters += 1
    elif i == "." or i == "?" or i == "!":
        sentence += 1

l = letters * (100/words)
s = sentence * (100/words)

index = round((0.0588 * l) - (0.296 * s) - 15.8)
if index < 1:
    print("Before Grade 1")
elif index >= 16:
    print("Grade 16+")
else:
    print("Grade", index)
