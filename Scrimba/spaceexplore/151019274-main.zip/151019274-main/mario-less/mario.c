#include <cs50.h>
#include <stdio.h>

int n;

int main(void)
{
    string s = " ";
    do
    {
        n = get_int("Height: ");
    }
    while (n < 1);

    for (int i = 1; i < n + 1; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (j >= n - i)
            {
                printf("#");
            }
            else
            {
                printf(" ");
            }
        }
        printf("\n");
    }
}
