#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, string argv[])
{
    int count;
    if (argc != 2)
    {
        printf("Usage: %s\n", argv[0]);
        return 1;
    }
    else if (strlen(argv[1]) != 26)
    {
        printf("Key must contain 26 characters.\n");
        return 1;
    }
    else
    {
        for (int i = 0; i < strlen(argv[1]); i++)
        {
            for (int j = 0; j < strlen(argv[1]); j++)
            {
                if (isalpha(argv[1][j]))
                {
                    if (argv[1][i] == argv[1][j])
                    {
                        count++;
                        if (count > 1)
                        {
                            return 1;
                        }
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    return 1;
                }
            }
            count = 0;
        }
        string text = get_string("plaintext: ");
        printf("ciphertext: ");

        for (int i = 0; i < strlen(text); i++)
        {
            if (islower(text[i]))
            {
                printf("%c", tolower(argv[1][(text[i] - 'a')]));
            }
            else if (isupper(text[i]))
            {
                printf("%c", toupper(argv[1][(text[i] - 'A')]));
            }
            else
            {
                printf("%c", text[i]);
            }
        }
        printf("\n");
        return 0;
    }
}
