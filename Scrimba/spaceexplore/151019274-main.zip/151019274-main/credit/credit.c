#include <cs50.h>
#include <stdio.h>

// Function to implement Luhn's Algorithm
bool luhnCheck(long cardNumber)
{
    int sum = 0;
    int isSecond = 0;

    while (cardNumber > 0)
    {
        int digit = cardNumber % 10;

        if (isSecond == 1)
        {
            digit *= 2;
            if (digit > 9)
            {
                digit -= 9;
            }
        }

        sum += digit;
        cardNumber /= 10;
        isSecond = !isSecond;
    }

    return (sum % 10 == 0);
}

// Function to get the length of the card number
int getLength(long cardNumber)
{
    int length = 0;
    while (cardNumber != 0)
    {
        cardNumber /= 10;
        length++;
    }
    return length;
}

// Function to identify and print the card type
void identifyCardType(long cardNumber)
{
    int length = getLength(cardNumber);

    // Get the first two digits to determine the card type
    long firstTwoDigits = cardNumber;
    while (firstTwoDigits >= 100)
    {
        firstTwoDigits /= 10;
    }

    // Get the first digit
    long firstDigit = cardNumber;
    while (firstDigit >= 10)
    {
        firstDigit /= 10;
    }

    // Check for card types
    if ((firstTwoDigits == 34 || firstTwoDigits == 37) && length == 15)
    {
        printf("AMEX\n");
    }
    else if ((firstTwoDigits >= 51 && firstTwoDigits <= 55) && length == 16)
    {
        printf("MASTERCARD\n");
    }
    else if (firstDigit == 4 && (length == 13 || length == 16))
    {
        printf("VISA\n");
    }
    else
    {
        printf("INVALID\n");
    }
}

int main(void)
{
    // Get the credit card number from the user
    long cardNumber = get_long("Number: ");

    // Check if the card number is valid
    if (luhnCheck(cardNumber))
    {
        identifyCardType(cardNumber);
    }
    else
    {
        printf("INVALID\n");
    }

    return 0;
}
