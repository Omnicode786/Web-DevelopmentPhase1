while True:
    try:
        cash = float(input("Change: "))
        if cash > 0:
            break
    except:
        pass

cash = int(round(100 * cash))

coins = cash // 25
rem = (cash % 25)
coins += rem // 10
rem = rem % 10
coins += rem // 5
rem = rem % 5
coins += rem // 1

print(coins)
