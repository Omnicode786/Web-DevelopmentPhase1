// Implements a dictionary's functionality

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#include "dictionary.h"

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
} node;

const unsigned int N = 26;
int count = 0;

// Hash table
node *table[N];

// Returns true if word is in dictionary, else false
bool check(const char *word)
{
    int hashy = hash(word);
    node *mynode = table[hashy];
    while (mynode != NULL)
    {
        if (strcasecmp(mynode->word, word) == 0)
        {
            return true;
        }
        mynode = mynode->next;
    }
    return false;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    // TODO: Improve this hash function
    return toupper(word[0]) - 'A';
}

// Loads dictionary into memory, returning true if successful, else false
bool load(const char *dictionary)
{
    FILE *ptr = fopen(dictionary, "r");
    if (ptr == NULL)
    {
        return false;
    }
    char word[LENGTH + 1];
    while (fscanf(ptr, "%s", word) != EOF)
    {
        node *mynode = malloc(sizeof(node));
        if (mynode == NULL)
        {
            return false;
        }
        strcpy(mynode->word, word);

        int hashy = hash(word);

        if (table[hashy] == NULL)
        {
            mynode->next = NULL;
        }
        else
        {
            mynode->next = table[hashy];
        }
        table[hashy] = mynode;
        count += 1;
    }
    fclose(ptr);
    return true;
}

// Returns number of words in dictionary if loaded, else 0 if not yet loaded
unsigned int size(void)
{
    return count;
}

// Unloads dictionary from memory, returning true if successful, else false
bool unload(void)
{
    for (int i = 0; i < N; i++)
    {
        node *cursor = table[i];
        while (cursor != NULL)
        {
            node *deleteNode = cursor;
            cursor = cursor->next;
            free(deleteNode);
        }
        table[i] = NULL;
    }
    return true;
}
