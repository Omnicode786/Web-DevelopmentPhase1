#include <cs50.h>
#include <stdio.h>

int n;

int main(void)
{
    string s = " ";

    do
    {
        n = get_int("Height: ");
    }
    while (n < 1);

    for (int i = 1; i < n + 1; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            for (int k = 0; k < n; k++)
            {
                if (j == 0)
                {
                    if (k >= n - i)
                    {
                        if (k == n - 1)
                        {
                            printf("#  ");
                        }
                        else
                        {
                            printf("#");
                        }
                    }
                    else
                    {
                        printf(" ");
                    }
                }
                else
                {
                    if (k >= n - i)
                    {
                        printf("#");
                    }
                }
            }
        }
        printf("\n");
    }
}
