#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>

int counter(string str);

int main(void)
{
    string val1 = get_string("Player 1: ");
    string val2 = get_string("Player 2: ");
    int qt1 = counter(val1);
    int qt2 = counter(val2);

    if (qt1 > qt2)
    {
        printf("Player 1 wins!\n");
    }
    else if (qt2 > qt1)
    {
        printf("Player 2 wins!\n");
    }
    else
    {
        printf("Tie!\n");
    }
}

int counter(string str)
{
    int count = 0;
    for (int i = 0, len = strlen(str); i < len; i++)
    {
        char ch = toupper(str[i]);
        if (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'L' || ch == 'N' || ch == 'O' ||
            ch == 'R' || ch == 'S' || ch == 'T' || ch == 'U')
        {
            count++;
        }
        else if (ch == 'B' || ch == 'C' || ch == 'M' || ch == 'P')
        {
            count += 3;
        }
        else if (ch == 'D' || ch == 'G')
        {
            count += 2;
        }
        else if (ch == 'F' || ch == 'H' || ch == 'V' || ch == 'W' || ch == 'Y')
        {
            count += 4;
        }
        else if (ch == 'J' || ch == 'X')
        {
            count += 8;
        }
        else if (ch == 'Q' || ch == 'Z')
        {
            count += 10;
        }
        else if (ch == 'K')
        {
            count += 5;
        }
        else
        {
            continue;
        }
    }
    return count;
}
