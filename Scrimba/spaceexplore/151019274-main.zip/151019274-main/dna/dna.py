import csv
import sys


def main():
    if len(sys.argv) == 3:
        rows1 = []
        with open(f"{sys.argv[1]}") as file:
            reader = csv.DictReader(file)
            for row in reader:
                rows1.append(row)

        rows2 = ''
        with open(f"{sys.argv[2]}") as file:
            rows2 = file.read()

        if sys.argv[1] == "databases/large.csv":
            AGATC = longest_match(rows2, "AGATC")
            TTTTTTCT = longest_match(rows2, "TTTTTTCT")
            AATG = longest_match(rows2, "AATG")
            TCTAG = longest_match(rows2, "TCTAG")
            GATA = longest_match(rows2, "GATA")
            TATC = longest_match(rows2, "TATC")
            GAAA = longest_match(rows2, "GAAA")
            TCTG = longest_match(rows2, "TCTG")

            for i in rows1:
                if (int(i["AGATC"]) == AGATC) and (int(i["TTTTTTCT"]) == TTTTTTCT) and (int(i["AATG"]) == AATG) and (int(i["TCTAG"]) == TCTAG) and (int(i["GATA"]) == GATA) and (int(i["TATC"]) == TATC) and (int(i["GAAA"]) == GAAA) and (int(i["TCTG"]) == TCTG):
                    print(i["name"])
                    break
            else:
                print("No match")
        else:
            AGATC = longest_match(rows2, "AGATC")
            AATG = longest_match(rows2, "AATG")
            TATC = longest_match(rows2, "TATC")

            for i in rows1:
                if (int(i["AGATC"]) == AGATC) and (int(i["AATG"]) == AATG) and (int(i["TATC"]) == TATC):
                    print(i["name"])
                    break
            else:
                print("No match")
    else:
        print("Please provide required arguments")
    return


def longest_match(sequence, subsequence):
    """Returns length of longest run of subsequence in sequence."""

    # Initialize variables
    longest_run = 0
    subsequence_length = len(subsequence)
    sequence_length = len(sequence)

    # Check each character in sequence for most consecutive runs of subsequence
    for i in range(sequence_length):

        # Initialize count of consecutive runs
        count = 0

        # Check for a subsequence match in a "substring" (a subset of characters) within sequence
        # If a match, move substring to next potential match in sequence
        # Continue moving substring and checking for matches until out of consecutive matches
        while True:

            # Adjust substring start and end
            start = i + count * subsequence_length
            end = start + subsequence_length

            # If there is a match in the substring
            if sequence[start:end] == subsequence:
                count += 1

            # If there is no match in the substring
            else:
                break

        # Update most consecutive matches found
        longest_run = max(longest_run, count)

    # After checking for runs at each character in seqeuence, return longest run found
    return longest_run


main()
