// Red Rotom Dex Application with Enhanced Audio
class AudioManager {
    constructor() {
        this.audioContext = null;
        this.masterVolume = 0.7;
        this.settings = {
            masterAudio: true,
            rotomVoice: true,
            rotomVoiceVolume: 0.8,
            rotomVoicePitch: 1.3,
            rotomVoiceRate: 1.2,
            pokemonCries: true,
            pokemonCriesVolume: 0.7,
            autoPlayCries: true,
            uiSounds: true,
            uiSoundsVolume: 0.5
        };
        
        this.currentCryAudio = null;
        this.currentSpeech = null;
        this.audioCache = new Map();
        
        this.loadSettings();
        this.initSynthesis();
    }

    initSynthesis() {
        if ('speechSynthesis' in window) {
            this.synthesis = window.speechSynthesis;
        }
    }

    loadSettings() {
        try {
            const saved = localStorage.getItem('rotomDexAudioSettings');
            if (saved) {
                this.settings = { ...this.settings, ...JSON.parse(saved) };
            }
            this.masterVolume = this.settings.masterAudio ? 0.7 : 0;
        } catch (error) {
            console.warn('Failed to load audio settings:', error);
        }
    }

    saveSettings() {
        try {
            localStorage.setItem('rotomDexAudioSettings', JSON.stringify(this.settings));
        } catch (error) {
            console.warn('Failed to save audio settings:', error);
        }
    }

    updateSetting(key, value) {
        this.settings[key] = value;
        if (key === 'masterAudio') {
            this.masterVolume = value ? 0.7 : 0;
        }
        this.saveSettings();
    }

    playUISound(type = 'click') {
        if (!this.settings.masterAudio || !this.settings.uiSounds) return;
        
        // Create simple UI sounds using Web Audio API
        try {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            const volume = this.masterVolume * this.settings.uiSoundsVolume * 0.3;
            gainNode.gain.setValueAtTime(volume, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.2);
            
            switch (type) {
                case 'click':
                    oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
                    oscillator.frequency.exponentialRampToValueAtTime(400, audioContext.currentTime + 0.1);
                    break;
                case 'hover':
                    oscillator.frequency.setValueAtTime(600, audioContext.currentTime);
                    break;
                case 'navigation':
                    oscillator.frequency.setValueAtTime(400, audioContext.currentTime);
                    oscillator.frequency.exponentialRampToValueAtTime(800, audioContext.currentTime + 0.15);
                    break;
                case 'error':
                    oscillator.frequency.setValueAtTime(200, audioContext.currentTime);
                    break;
            }
            
            oscillator.type = 'square';
            oscillator.start();
            oscillator.stop(audioContext.currentTime + 0.2);
        } catch (error) {
            console.warn('UI sound failed:', error);
        }
    }

    async playPokemonCry(pokemonName) {
        if (!this.settings.masterAudio || !this.settings.pokemonCries) return null;

        const cryUrl = `https://play.pokemonshowdown.com/audio/cries/${pokemonName.toLowerCase()}.mp3`;
        
        try {
            // Stop current cry if playing
            if (this.currentCryAudio) {
                this.currentCryAudio.pause();
                this.currentCryAudio = null;
            }

            // Check cache first
            if (this.audioCache.has(cryUrl)) {
                const audio = this.audioCache.get(cryUrl).cloneNode();
                audio.volume = this.masterVolume * this.settings.pokemonCriesVolume;
                audio.play();
                this.currentCryAudio = audio;
                return audio;
            }

            // Load and play new audio
            const audio = new Audio(cryUrl);
            audio.volume = this.masterVolume * this.settings.pokemonCriesVolume;
            
            audio.onloadeddata = () => {
                this.audioCache.set(cryUrl, audio.cloneNode());
            };

            audio.onerror = () => {
                console.warn(`Failed to load cry for ${pokemonName}`);
            };

            await audio.play();
            this.currentCryAudio = audio;
            return audio;
            
        } catch (error) {
            console.warn(`Error playing cry for ${pokemonName}:`, error);
            return null;
        }
    }

    speakRotomText(text, options = {}) {
        if (!this.settings.masterAudio || !this.settings.rotomVoice) return null;
        if (!this.synthesis) return null;

        // Stop current speech
        this.synthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        
        // Configure robotic Rotom voice
        utterance.pitch = options.pitch || this.settings.rotomVoicePitch;
        utterance.rate = options.rate || this.settings.rotomVoiceRate;
        utterance.volume = (this.masterVolume * this.settings.rotomVoiceVolume) || 0.8;
        
        // Try to find a robotic-sounding voice
        const voices = this.synthesis.getVoices();
        const roboticVoice = voices.find(voice => 
            voice.name.includes('Microsoft') || 
            voice.name.includes('Google') ||
            voice.lang.includes('en')
        );
        
        if (roboticVoice) {
            utterance.voice = roboticVoice;
        }

        this.synthesis.speak(utterance);
        this.currentSpeech = utterance;
        
        return utterance;
    }

    showVoiceWave(elementId) {
        const element = document.getElementById(elementId);
        if (element) {
            element.classList.remove('hidden');
            setTimeout(() => {
                element.classList.add('hidden');
            }, 3000);
        }
    }

    showCryVisualizer() {
        const visualizer = document.getElementById('cryVisualizer');
        if (visualizer) {
            visualizer.classList.remove('hidden');
            setTimeout(() => {
                visualizer.classList.add('hidden');
            }, 2000);
        }
    }

    pulseRotomEyes() {
        const leftPulse = document.getElementById('leftEyePulse');
        const rightPulse = document.getElementById('rightEyePulse');
        
        if (leftPulse) leftPulse.style.animation = 'eyePulse 1s ease-out';
        if (rightPulse) rightPulse.style.animation = 'eyePulse 1s ease-out';
        
        setTimeout(() => {
            if (leftPulse) leftPulse.style.animation = '';
            if (rightPulse) rightPulse.style.animation = '';
        }, 1000);
    }
}

class RotomDexApp {
    constructor() {
        // Initialize audio manager first
        this.audioManager = new AudioManager();
        
        // App state
        this.currentView = 'map';
        this.currentPokemon = null;
        this.pokemonList = [];
        this.filteredPokemon = [];
        this.pokemonCache = new Map();
        this.currentGeneration = 'all';
        this.isShinyMode = false;
        this.isLoading = false;

        // Enhanced voice lines
        this.rotomComments = [
            "Zzzt! Let me help you find that Pokémon!",
            "Bzzt! This one's really interesting!",
            "Rotom-dex at your service! ⚡",
            "Zzzt! Want to hear its cry?",
            "Bzzt bzzt! Amazing stats on this one!",
            "Rotom thinks this Pokémon is super cool!",
            "Zzzt! Don't forget to check its abilities!",
            "Bzzt! Perfect for your team! ⚡",
            "Zzzt! This Pokémon has incredible potential!",
            "Bzzt bzzt! One of my favorites! ⚡"
        ];

        this.rotomGreetings = [
            "Zzzt! Welcome to Alola! Ready to explore? ⚡",
            "Bzzt! Let's discover some amazing Pokémon!",
            "Zzzt! The Alola region is full of surprises! ⚡",
            "Bzzt bzzt! Your adventure starts here!",
            "Zzzt! I'll help you become the best trainer! ⚡"
        ];

        this.rotomVoiceLines = {
            search: "Bzzt! Searching for that Pokémon! ⚡",
            generationChange: "Zzzt! Switching to {generation} region! ⚡",
            shinyToggle: "Bzzt! Shiny mode activated! Sparkle sparkle! ⚡",
            loading: "Zzzt! Loading data! Please wait! ⚡",
            error: "Bzzt bzzt! Something went wrong! Let me try again! ⚡"
        };

        // Enhanced generation data with all 9 generations
        this.generations = {
            '1': { name: 'Kanto', limit: 151, offset: 0, total: 151 },
            '2': { name: 'Johto', limit: 100, offset: 151, total: 251 },
            '3': { name: 'Hoenn', limit: 135, offset: 251, total: 386 },
            '4': { name: 'Sinnoh', limit: 107, offset: 386, total: 493 },
            '5': { name: 'Unova', limit: 156, offset: 493, total: 649 },
            '6': { name: 'Kalos', limit: 72, offset: 649, total: 721 },
            '7': { name: 'Alola', limit: 88, offset: 721, total: 809 },
            '8': { name: 'Galar', limit: 96, offset: 809, total: 905 },
            '9': { name: 'Paldea', limit: 120, offset: 905, total: 1025 }
        };

        // Type colors
        this.typeColors = {
            normal: '#A8A878', fire: '#F08030', water: '#6890F0', electric: '#F8D030',
            grass: '#78C850', ice: '#98D8D8', fighting: '#C03028', poison: '#A040A0',
            ground: '#E0C068', flying: '#A890F0', psychic: '#F85888', bug: '#A8B820',
            rock: '#B8A038', ghost: '#705898', dragon: '#7038F8', dark: '#705848',
            steel: '#B8B8D0', fairy: '#EE99AC'
        };

        this.init();
    }

    async init() {
        this.bindEvents();
        this.initAudioSettings();
        this.startRotomAnimations();
        this.playWelcomeMessage();
        // Pre-load Pokemon data for faster navigation
        await this.loadInitialPokemon();
    }

    initAudioSettings() {
        // Populate audio settings modal with current values
        const settings = this.audioManager.settings;
        
        const updateElement = (id, value, isCheckbox = false) => {
            const element = document.getElementById(id);
            if (element) {
                if (isCheckbox) {
                    element.checked = value;
                } else {
                    element.value = value;
                }
                
                // Update display for volume/pitch/rate controls
                const displayElement = document.getElementById(id + 'Display');
                if (displayElement) {
                    if (id.includes('Volume')) {
                        displayElement.textContent = Math.round(value * 100) + '%';
                    } else if (id.includes('Pitch') || id.includes('Rate')) {
                        displayElement.textContent = value.toFixed(1);
                    }
                }
            }
        };

        updateElement('masterAudioToggle', settings.masterAudio, true);
        updateElement('masterVolume', settings.masterAudio ? 0.7 : 0);
        updateElement('rotomVoiceToggle', settings.rotomVoice, true);
        updateElement('rotomVoiceVolume', settings.rotomVoiceVolume);
        updateElement('rotomVoicePitch', settings.rotomVoicePitch);
        updateElement('rotomVoiceRate', settings.rotomVoiceRate);
        updateElement('pokemonCriesToggle', settings.pokemonCries, true);
        updateElement('pokemonCriesVolume', settings.pokemonCriesVolume);
        updateElement('autoPlayCriesToggle', settings.autoPlayCries, true);
        updateElement('uiSoundsToggle', settings.uiSounds, true);
        updateElement('uiSoundsVolume', settings.uiSoundsVolume);
    }

    bindEvents() {
        // Audio settings events
        this.bindEvent('audioSettingsBtn', 'click', () => {
            this.audioManager.playUISound('click');
            this.showAudioSettings();
        });
        
        this.bindEvent('closeAudioSettings', 'click', () => {
            this.audioManager.playUISound('click');
            this.hideAudioSettings();
        });

        // Modal close on outside click
        this.bindEvent('audioSettingsModal', 'click', (e) => {
            if (e.target.id === 'audioSettingsModal') {
                this.hideAudioSettings();
            }
        });

        // Audio control bindings
        this.bindAudioControls();

        // FIXED NAVIGATION - Ensure eye clicks work properly
        this.bindEvent('leftEye', 'click', () => {
            console.log('Left eye clicked - switching to map view');
            this.audioManager.playUISound('navigation');
            this.switchToMapView();
        });
        
        this.bindEvent('rightEye', 'click', () => {
            console.log('Right eye clicked - switching to pokedex view');
            this.audioManager.playUISound('navigation');
            this.switchToPokedexView();
        });

        // Lightning bolt navigation
        this.bindEvent('leftBolt', 'click', () => {
            this.audioManager.playUISound('click');
            this.handleLeftBolt();
        });
        
        this.bindEvent('rightBolt', 'click', () => {
            this.audioManager.playUISound('click');
            this.handleRightBolt();
        });

        // Search functionality
        this.bindEvent('pokemonSearch', 'input', (e) => {
            if (e.target.value.length > 0) {
                this.audioManager.playUISound('click');
                this.speakRotomLine(this.rotomVoiceLines.search);
            }
            this.handleSearch(e.target.value);
        });

        // Generation filter
        this.bindEvent('generationFilter', 'change', (e) => {
            this.audioManager.playUISound('navigation');
            const genName = e.target.value === 'all' ? 'all' : this.generations[e.target.value]?.name || '';
            const message = this.rotomVoiceLines.generationChange.replace('{generation}', genName);
            this.speakRotomLine(message);
            this.handleGenerationChange(e.target.value);
        });

        // Shiny toggle
        this.bindEvent('shinyToggle', 'click', () => {
            this.audioManager.playUISound('click');
            this.speakRotomLine(this.rotomVoiceLines.shinyToggle);
            this.toggleShinyMode();
        });

        // Detail view controls
        this.bindEvent('backToList', 'click', () => {
            this.audioManager.playUISound('navigation');
            this.switchToPokedexView();
        });

        this.bindEvent('detailCryBtn', 'click', () => {
            if (this.currentPokemon) {
                this.playPokemonCry(this.currentPokemon.name);
            }
        });

        this.bindEvent('normalBtn', 'click', () => {
            this.audioManager.playUISound('click');
            this.showNormalSprite();
        });
        
        this.bindEvent('shinyBtn', 'click', () => {
            this.audioManager.playUISound('click');
            this.showShinySprite();
        });

        // ESC key to close modal
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.hideAudioSettings();
            }
        });
    }

    bindEvent(id, event, handler) {
        const element = document.getElementById(id);
        if (element) {
            element.addEventListener(event, handler);
        } else {
            console.warn(`Element with id '${id}' not found`);
        }
    }

    bindAudioControls() {
        // Master audio controls
        this.bindEvent('masterAudioToggle', 'change', (e) => {
            this.audioManager.updateSetting('masterAudio', e.target.checked);
            this.updateAudioDisplay('masterVolume', e.target.checked ? 0.7 : 0);
        });

        this.bindEvent('masterVolume', 'input', (e) => {
            const value = parseFloat(e.target.value);
            this.audioManager.masterVolume = value;
            this.updateAudioDisplay('masterVolume', value);
        });

        // Rotom voice controls
        this.bindEvent('rotomVoiceToggle', 'change', (e) => {
            this.audioManager.updateSetting('rotomVoice', e.target.checked);
        });

        this.bindEvent('rotomVoiceVolume', 'input', (e) => {
            const value = parseFloat(e.target.value);
            this.audioManager.updateSetting('rotomVoiceVolume', value);
            this.updateAudioDisplay('rotomVoiceVolume', value);
        });

        this.bindEvent('rotomVoicePitch', 'input', (e) => {
            const value = parseFloat(e.target.value);
            this.audioManager.updateSetting('rotomVoicePitch', value);
            this.updateAudioDisplay('rotomVoicePitch', value);
        });

        this.bindEvent('rotomVoiceRate', 'input', (e) => {
            const value = parseFloat(e.target.value);
            this.audioManager.updateSetting('rotomVoiceRate', value);
            this.updateAudioDisplay('rotomVoiceRate', value);
        });

        // Pokemon cry controls
        this.bindEvent('pokemonCriesToggle', 'change', (e) => {
            this.audioManager.updateSetting('pokemonCries', e.target.checked);
        });

        this.bindEvent('pokemonCriesVolume', 'input', (e) => {
            const value = parseFloat(e.target.value);
            this.audioManager.updateSetting('pokemonCriesVolume', value);
            this.updateAudioDisplay('pokemonCriesVolume', value);
        });

        this.bindEvent('autoPlayCriesToggle', 'change', (e) => {
            this.audioManager.updateSetting('autoPlayCries', e.target.checked);
        });

        // UI sound controls
        this.bindEvent('uiSoundsToggle', 'change', (e) => {
            this.audioManager.updateSetting('uiSounds', e.target.checked);
        });

        this.bindEvent('uiSoundsVolume', 'input', (e) => {
            const value = parseFloat(e.target.value);
            this.audioManager.updateSetting('uiSoundsVolume', value);
            this.updateAudioDisplay('uiSoundsVolume', value);
        });
    }

    updateAudioDisplay(type, value) {
        const displayId = type + 'Display';
        const displayElement = document.getElementById(displayId);
        if (displayElement) {
            if (type.includes('Volume')) {
                displayElement.textContent = Math.round(value * 100) + '%';
            } else {
                displayElement.textContent = value.toFixed(1);
            }
        }
    }

    showAudioSettings() {
        const modal = document.getElementById('audioSettingsModal');
        if (modal) {
            modal.classList.remove('hidden');
        }
    }

    hideAudioSettings() {
        const modal = document.getElementById('audioSettingsModal');
        if (modal) {
            modal.classList.add('hidden');
        }
    }

    speakRotomLine(text) {
        const utterance = this.audioManager.speakRotomText(text);
        if (utterance) {
            this.audioManager.pulseRotomEyes();
            
            // Show voice wave indicator based on current view
            if (this.currentView === 'map') {
                this.audioManager.showVoiceWave('greetingVoiceWave');
            } else if (this.currentView === 'detail') {
                this.audioManager.showVoiceWave('commentVoiceWave');
            }
        }
    }

    async playPokemonCry(pokemonName) {
        this.audioManager.playUISound('click');
        const audio = await this.audioManager.playPokemonCry(pokemonName);
        if (audio) {
            this.audioManager.showCryVisualizer();
        }
    }

    playWelcomeMessage() {
        setTimeout(() => {
            this.showRandomGreeting();
        }, 1000);
    }

    startRotomAnimations() {
        // Random greeting changes
        setInterval(() => {
            if (this.currentView === 'map') {
                this.showRandomGreeting();
            }
        }, 15000);

        // Random comment changes in detail view
        setInterval(() => {
            if (this.currentView === 'detail' && this.currentPokemon) {
                this.showRandomComment();
            }
        }, 12000);
    }

    showRandomGreeting() {
        const greeting = this.rotomGreetings[Math.floor(Math.random() * this.rotomGreetings.length)];
        const greetingElement = document.getElementById('rotomGreeting');
        if (greetingElement) {
            greetingElement.textContent = greeting;
        }
        this.speakRotomLine(greeting);
    }

    showRandomComment() {
        const comment = this.rotomComments[Math.floor(Math.random() * this.rotomComments.length)];
        const commentElement = document.getElementById('rotomComment');
        if (commentElement) {
            commentElement.textContent = comment;
        }
        this.speakRotomLine(comment);
    }

    shakeDevice() {
        const device = document.querySelector('.rotom-device');
        if (device) {
            device.classList.add('device-shake');
            setTimeout(() => {
                device.classList.remove('device-shake');
            }, 500);
        }
    }

    switchToMapView() {
        console.log('Switching to map view');
        this.currentView = 'map';
        this.showView('mapView');
        this.shakeDevice();
    }

    switchToPokedexView() {
        console.log('Switching to pokedex view');
        this.currentView = 'pokedex';
        this.showView('pokedexView');
        this.shakeDevice();
        
        // Render Pokemon grid immediately if data is already loaded
        if (this.pokemonList.length > 0) {
            this.renderPokemonGrid();
        }
    }

    switchToDetailView(pokemon) {
        console.log('Switching to detail view for', pokemon.name);
        this.currentView = 'detail';
        this.currentPokemon = pokemon;
        this.showView('detailView');
        this.populateDetailView(pokemon);
        this.showRandomComment();
        this.shakeDevice();
        
        // Auto-play cry if enabled
        if (this.audioManager.settings.autoPlayCries) {
            setTimeout(() => {
                this.playPokemonCry(pokemon.name);
            }, 500);
        }
    }

    showView(viewId) {
        console.log('Showing view:', viewId);
        
        // Hide all views
        document.querySelectorAll('.view-container').forEach(view => {
            view.classList.remove('active');
        });
        
        // Show target view
        const targetView = document.getElementById(viewId);
        if (targetView) {
            targetView.classList.add('active');
            console.log('Successfully activated view:', viewId);
        } else {
            console.error('View not found:', viewId);
        }
    }

    async loadInitialPokemon() {
        if (this.isLoading) return;
        
        this.showLoading(true);
        
        try {
            // Load Kanto region by default
            const response = await fetch('https://pokeapi.co/api/v2/pokemon?limit=151&offset=0');
            if (!response.ok) throw new Error('Failed to fetch Pokemon');
            
            const data = await response.json();
            
            this.pokemonList = data.results.map((pokemon, index) => ({
                id: index + 1,
                name: pokemon.name,
                url: pokemon.url
            }));
            
            this.filteredPokemon = [...this.pokemonList];
            console.log('Loaded', this.pokemonList.length, 'Pokemon');
            
        } catch (error) {
            console.error('Error loading Pokemon:', error);
            this.speakRotomLine(this.rotomVoiceLines.error);
        } finally {
            this.showLoading(false);
        }
    }

    async handleGenerationChange(generation) {
        if (generation === this.currentGeneration) return;
        
        this.currentGeneration = generation;
        this.showLoading(true);
        this.speakRotomLine(this.rotomVoiceLines.loading);
        
        try {
            let pokemonData = [];
            
            if (generation === 'all') {
                // Load first 3 generations for performance
                const generations = ['1', '2', '3'];
                const promises = generations.map(async (gen) => {
                    const genData = this.generations[gen];
                    const response = await fetch(`https://pokeapi.co/api/v2/pokemon?limit=${genData.limit}&offset=${genData.offset}`);
                    const data = await response.json();
                    return data.results.map((pokemon, index) => ({
                        id: genData.offset + index + 1,
                        name: pokemon.name,
                        url: pokemon.url
                    }));
                });
                
                const results = await Promise.all(promises);
                pokemonData = results.flat();
            } else {
                const genData = this.generations[generation];
                if (!genData) {
                    console.error('Unknown generation:', generation);
                    return;
                }
                
                const response = await fetch(`https://pokeapi.co/api/v2/pokemon?limit=${genData.limit}&offset=${genData.offset}`);
                const data = await response.json();
                pokemonData = data.results.map((pokemon, index) => ({
                    id: genData.offset + index + 1,
                    name: pokemon.name,
                    url: pokemon.url
                }));
            }
            
            this.pokemonList = pokemonData;
            this.filteredPokemon = [...this.pokemonList];
            
            const searchInput = document.getElementById('pokemonSearch');
            if (searchInput) searchInput.value = '';
            
            await this.renderPokemonGrid();
            
        } catch (error) {
            console.error('Error loading generation:', error);
            this.speakRotomLine(this.rotomVoiceLines.error);
        } finally {
            this.showLoading(false);
        }
    }

    handleSearch(query) {
        if (!query.trim()) {
            this.filteredPokemon = [...this.pokemonList];
        } else {
            const searchTerm = query.toLowerCase();
            this.filteredPokemon = this.pokemonList.filter(pokemon => 
                pokemon.name.toLowerCase().includes(searchTerm) ||
                pokemon.id.toString().includes(searchTerm)
            );
        }
        this.renderPokemonGrid();
    }

    toggleShinyMode() {
        this.isShinyMode = !this.isShinyMode;
        const shinyBtn = document.getElementById('shinyToggle');
        
        if (shinyBtn) {
            if (this.isShinyMode) {
                shinyBtn.classList.add('active');
            } else {
                shinyBtn.classList.remove('active');
            }
        }
        
        // Re-render current view with new sprite mode
        if (this.currentView === 'pokedex') {
            this.renderPokemonGrid();
        } else if (this.currentView === 'detail' && this.currentPokemon) {
            this.updateDetailSprite();
        }
        
        this.shakeDevice();
    }

    async renderPokemonGrid() {
        const grid = document.getElementById('pokemonGrid');
        if (!grid) {
            console.error('Pokemon grid element not found');
            return;
        }
        
        if (this.filteredPokemon.length === 0) {
            grid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; color: var(--rotom-text-secondary); padding: var(--space-20);">No Pokémon found</div>';
            return;
        }
        
        // Show first 20 Pokemon for performance
        const displayPokemon = this.filteredPokemon.slice(0, 20);
        console.log('Rendering', displayPokemon.length, 'Pokemon cards');
        
        grid.innerHTML = displayPokemon.map(pokemon => this.createPokemonCard(pokemon)).join('');
        
        // Load detailed data for visible Pokemon
        await this.loadPokemonDetails(displayPokemon);
        
        // Add event listeners to cards
        this.bindPokemonCardEvents();
    }

    bindPokemonCardEvents() {
        const grid = document.getElementById('pokemonGrid');
        if (!grid) return;

        // Add click handlers for cards
        grid.querySelectorAll('.pokemon-card').forEach(card => {
            card.addEventListener('click', async (e) => {
                // Don't trigger if cry button was clicked
                if (e.target.closest('.card-cry-btn')) return;
                
                this.audioManager.playUISound('click');
                const pokemonId = parseInt(card.dataset.pokemonId);
                const pokemon = await this.getPokemonDetails(pokemonId);
                if (pokemon) {
                    this.switchToDetailView(pokemon);
                }
            });
        });
        
        // Add cry button handlers
        grid.querySelectorAll('.card-cry-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.stopPropagation();
                const pokemonName = btn.dataset.pokemonName;
                if (pokemonName) {
                    await this.playPokemonCry(pokemonName);
                }
            });
        });
    }

    createPokemonCard(pokemon) {
        const spriteUrl = this.isShinyMode 
            ? `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/${pokemon.id}.png`
            : `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${pokemon.id}.png`;
        
        return `
            <div class="pokemon-card" data-pokemon-id="${pokemon.id}">
                <div class="pokemon-card-header">
                    <div class="pokemon-card-id">#${pokemon.id.toString().padStart(3, '0')}</div>
                    <button class="card-cry-btn" data-pokemon-name="${pokemon.name}" title="Play Cry">🔊</button>
                </div>
                <img class="pokemon-card-sprite" src="${spriteUrl}" alt="${pokemon.name}" loading="lazy">
                <div class="pokemon-card-name">${this.capitalize(pokemon.name)}</div>
                <div class="pokemon-card-types" id="types-${pokemon.id}">
                    <div class="type-badge" style="background: #666;">Loading...</div>
                </div>
            </div>
        `;
    }

    async loadPokemonDetails(pokemonList) {
        const promises = pokemonList.map(async (pokemon) => {
            const details = await this.getPokemonDetails(pokemon.id);
            if (details) {
                const typesContainer = document.getElementById(`types-${pokemon.id}`);
                if (typesContainer) {
                    typesContainer.innerHTML = details.types.map(type => 
                        `<span class="type-badge type-${type}">${this.capitalize(type)}</span>`
                    ).join('');
                }
            }
        });
        
        await Promise.all(promises);
    }

    async getPokemonDetails(pokemonId) {
        if (this.pokemonCache.has(pokemonId)) {
            return this.pokemonCache.get(pokemonId);
        }
        
        try {
            const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonId}`);
            if (!response.ok) throw new Error(`Failed to fetch Pokemon ${pokemonId}`);
            
            const data = await response.json();
            
            const pokemon = {
                id: data.id,
                name: data.name,
                types: data.types.map(t => t.type.name),
                sprites: {
                    normal: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${data.id}.png`,
                    shiny: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/${data.id}.png`,
                    artwork: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${data.id}.png`
                },
                stats: data.stats.map(s => ({
                    name: s.stat.name,
                    value: s.base_stat
                })),
                height: data.height,
                weight: data.weight,
                abilities: data.abilities.map(a => a.ability.name),
                category: 'Unknown Pokémon'
            };
            
            this.pokemonCache.set(pokemonId, pokemon);
            return pokemon;
            
        } catch (error) {
            console.error(`Error loading Pokemon ${pokemonId}:`, error);
            return null;
        }
    }

    populateDetailView(pokemon) {
        // Update basic info
        this.updateElement('detailNumber', `#${pokemon.id.toString().padStart(3, '0')}`);
        this.updateElement('detailName', this.capitalize(pokemon.name));
        this.updateElement('detailCategory', pokemon.category);
        
        // Update sprite
        this.updateDetailSprite();
        
        // Update types
        const typesContainer = document.getElementById('detailTypes');
        if (typesContainer) {
            typesContainer.innerHTML = pokemon.types.map(type => 
                `<span class="type-badge type-${type}">${this.capitalize(type)}</span>`
            ).join('');
        }
        
        // Update physical stats
        this.updateElement('detailHeight', `${(pokemon.height / 10).toFixed(1)} m`);
        this.updateElement('detailWeight', `${(pokemon.weight / 10).toFixed(1)} kg`);
        
        // Update abilities
        const abilitiesContainer = document.getElementById('detailAbilities');
        if (abilitiesContainer) {
            abilitiesContainer.innerHTML = pokemon.abilities.map(ability => 
                `<span class="ability-badge">${this.capitalize(ability.replace('-', ' '))}</span>`
            ).join('');
        }
        
        // Update stats
        this.renderStats(pokemon.stats);
        this.updateSpriteButtons();
    }

    updateElement(id, content) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = content;
        }
    }

    updateDetailSprite() {
        if (!this.currentPokemon) return;
        
        const sprite = document.getElementById('detailSprite');
        if (sprite) {
            const spriteUrl = this.isShinyMode 
                ? this.currentPokemon.sprites.shiny 
                : this.currentPokemon.sprites.normal;
                
            sprite.src = spriteUrl;
            sprite.alt = this.currentPokemon.name;
        }
    }

    showNormalSprite() {
        this.isShinyMode = false;
        this.updateDetailSprite();
        this.updateSpriteButtons();
    }

    showShinySprite() {
        this.isShinyMode = true;
        this.updateDetailSprite();
        this.updateSpriteButtons();
    }

    updateSpriteButtons() {
        const normalBtn = document.getElementById('normalBtn');
        const shinyBtn = document.getElementById('shinyBtn');
        
        if (normalBtn && shinyBtn) {
            if (this.isShinyMode) {
                normalBtn.classList.remove('active');
                shinyBtn.classList.add('active');
            } else {
                normalBtn.classList.add('active');
                shinyBtn.classList.remove('active');
            }
        }
    }

    renderStats(stats) {
        const statsContainer = document.getElementById('detailStats');
        if (!statsContainer) return;

        const statNames = {
            'hp': 'HP',
            'attack': 'ATK',
            'defense': 'DEF',
            'special-attack': 'SP.ATK',
            'special-defense': 'SP.DEF',
            'speed': 'SPD'
        };
        
        statsContainer.innerHTML = stats.map(stat => {
            const percentage = Math.min((stat.value / 150) * 100, 100);
            return `
                <div class="stat-row">
                    <div class="stat-name">${statNames[stat.name] || stat.name.toUpperCase()}</div>
                    <div class="stat-bar">
                        <div class="stat-fill" style="width: ${percentage}%"></div>
                    </div>
                    <div class="stat-number">${stat.value}</div>
                </div>
            `;
        }).join('');
    }

    handleLeftBolt() {
        if (this.currentView === 'detail' && this.currentPokemon) {
            const currentIndex = this.filteredPokemon.findIndex(p => p.id === this.currentPokemon.id);
            if (currentIndex > 0) {
                this.navigateToPokemon(currentIndex - 1);
            }
        }
        this.shakeDevice();
    }

    handleRightBolt() {
        if (this.currentView === 'detail' && this.currentPokemon) {
            const currentIndex = this.filteredPokemon.findIndex(p => p.id === this.currentPokemon.id);
            if (currentIndex < this.filteredPokemon.length - 1) {
                this.navigateToPokemon(currentIndex + 1);
            }
        }
        this.shakeDevice();
    }

    async navigateToPokemon(index) {
        const pokemon = await this.getPokemonDetails(this.filteredPokemon[index].id);
        if (pokemon) {
            this.switchToDetailView(pokemon);
        }
    }

    showLoading(show) {
        const loading = document.getElementById('loadingState');
        if (loading) {
            if (show) {
                loading.classList.remove('hidden');
                this.isLoading = true;
            } else {
                loading.classList.add('hidden');
                this.isLoading = false;
            }
        }
    }

    capitalize(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }
}

// Initialize the Enhanced Rotom Dex when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing Rotom Dex...');
    window.rotomDex = new RotomDexApp();
    
    // Enable audio context on first user interaction
    document.addEventListener('click', () => {
        if (window.rotomDex && window.rotomDex.audioManager) {
            try {
                const AudioContext = window.AudioContext || window.webkitAudioContext;
                if (AudioContext && !window.rotomDex.audioManager.audioContext) {
                    window.rotomDex.audioManager.audioContext = new AudioContext();
                }
            } catch (error) {
                console.warn('Audio context initialization failed:', error);
            }
        }
    }, { once: true });
});